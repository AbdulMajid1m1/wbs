// import Redis from "ioredis";

// const client = new Redis({
//     host: "172.21.73.77",
//     port: 6380,
// });

// client.on("connect", () => {
//     console.log("Connected to Redis server");
// });

// client.on("error", (err) => {
//     console.log("Error connecting to Redis server:", err);
// });

// export { client };
