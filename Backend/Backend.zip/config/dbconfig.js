export const config1 = {
  user: "sa",
  password: "its2514LOVE!",
  server: "173.249.56.16",
  database: "Alessa_Ax2009_Live",
  options: {
    trustServerCertificate: true,
  },
  // increase request timeout to 1 minute
  // requestTimeout: 180000,

  // change request timout to 5 sec
  requestTimeout: 1000,

};


export const config2 = {
  user: "sa",
  password: "its2514LOVE!",
  server: "173.249.56.16",
  database: "WBSSQL",
  options: {
    trustServerCertificate: true,
  },
  // 1 minute
  // requestTimeout: 180000,
  requestTimeout: 1000,
};

