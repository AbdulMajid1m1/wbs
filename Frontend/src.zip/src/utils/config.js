const baseUrl = 'http://localhost:3005/api'
// const baseUrl = 'http://37.224.47.116:7474/api'
// const baseUrl = 'http://gs1ksa.org:3005/api'

// const baseUrl = 'http://37.224.47.116:7474/api'
//  const baseUrl = "http://10.10.12.153:3005/api";
export default baseUrl;
 
