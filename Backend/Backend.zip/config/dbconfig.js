var config = {
    user: "sa",
    password: "its2514LOVE!",
    server: "173.249.56.16",
    database: "Alessa_Ax2009_Live",
    options: {
      trustServerCertificate: true,
    },
  };
export default config;
  