
import sql from "mssql";
import { config1, config2 } from "./dbconfig.js";

const pool1 = new sql.ConnectionPool(config1);
const pool2 = new sql.ConnectionPool(config2);

const pool1ConnectPromise = pool1.connect();
pool1ConnectPromise.catch((err) => console.log("Error connecting to config1:", err));

const pool2ConnectPromise = pool2.connect();
pool2ConnectPromise.catch((err) => console.log("Error connecting to config2:", err));

export { pool1, pool2, pool1ConnectPromise, pool2ConnectPromise };

